function getDiagnosis(category) {
    const selectedSymptoms = [];
    document.querySelectorAll('.form-check-input:checked').forEach(checkbox => {
        selectedSymptoms.push(checkbox.value);
    });

    if (selectedSymptoms.length === 0) {
        alert('Please select at least one symptom');
        return;
    }

    const loadingSpinner = document.getElementById('loadingSpinner');
    const resultsDiv = document.getElementById('diagnosisResults');
    
    loadingSpinner.classList.remove('d-none');
    resultsDiv.innerHTML = '';

    fetch('/get_diagnosis', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            category: category,
            symptoms: selectedSymptoms
        })
    })
    .then(response => response.json())
    .then(data => {
        loadingSpinner.classList.add('d-none');
        
        if (data.error) {
            resultsDiv.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
            return;
        }

        const result = JSON.parse(data);
        
        resultsDiv.innerHTML = `
            <div class="diagnosis-result">
                <h4 class="mb-3">Possible Diagnosis</h4>
                <p class="diagnosis-text">${result.diagnosis}</p>
                
                <h4 class="mb-3 mt-4">Precautions</h4>
                <ul class="precautions-list">
                    ${result.precautions.map(p => `<li>${p}</li>`).join('')}
                </ul>
                
                <h4 class="mb-3 mt-4">Home Remedies</h4>
                <ul class="remedies-list">
                    ${result.remedies.map(r => `<li>${r}</li>`).join('')}
                </ul>
                
                <div class="alert alert-warning mt-4">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    This is an AI-generated diagnosis. Please consult a healthcare professional for accurate medical advice.
                </div>
            </div>
        `;
    })
    .catch(error => {
        loadingSpinner.classList.add('d-none');
        resultsDiv.innerHTML = `<div class="alert alert-danger">Error: ${error.message}</div>`;
    });
}

function sendMessage() {
    const userInput = document.getElementById('userMessage');
    const message = userInput.value.trim();
    
    if (!message) return;
    
    const chatMessages = document.getElementById('chatMessages');
    
    // Add user message
    chatMessages.innerHTML += `
        <div class="message user">
            ${message}
        </div>
    `;
    
    userInput.value = '';
    
    // Add loading message
    const loadingId = 'loading-' + Date.now();
    chatMessages.innerHTML += `
        <div class="message system" id="${loadingId}">
            <div class="spinner-border spinner-border-sm" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;
    
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    fetch('/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: message })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById(loadingId).remove();
        
        chatMessages.innerHTML += `
            <div class="message system">
                ${data.response}
            </div>
        `;
        
        chatMessages.scrollTop = chatMessages.scrollHeight;
    })
    .catch(error => {
        document.getElementById(loadingId).remove();
        
        chatMessages.innerHTML += `
            <div class="message system text-danger">
                Error: Unable to get response. Please try again.
            </div>
        `;
        
        chatMessages.scrollTop = chatMessages.scrollHeight;
    });
}

function calculateBMI(event) {
    event.preventDefault();

    const weight = parseFloat(document.getElementById('weight').value);
    const height = parseFloat(document.getElementById('height').value);

    fetch('/calculate_bmi', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            weight: weight,
            height: height
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
            return;
        }

        const resultDiv = document.getElementById('bmiResult');
        document.getElementById('bmiValue').textContent = data.bmi;
        document.getElementById('bmiCategory').textContent = data.category;
        resultDiv.classList.remove('d-none');
    })
    .catch(error => {
        alert('Error calculating BMI: ' + error.message);
    });
}

// Add enter key listener for chat input
document.getElementById('userMessage')?.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});